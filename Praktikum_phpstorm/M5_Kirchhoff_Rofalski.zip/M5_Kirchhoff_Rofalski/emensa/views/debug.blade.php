<h1>This is a blade view showing phpinfo();</h1>

<!-- <pre>
@verbatim
    @php
    phpinfo();
    @endphp
@endverbatim
</pre> -->

@php
phpinfo();
@endphp