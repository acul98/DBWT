<html>
<body>

<form method = "GET" action="m4_7a_queryparameter">
    <label for="eingabe">Eingabe:</label>
    <input id="eingabe" type="text" name="name">

    <input type="submit" value="Abschicken">
</form>

Die Eingabe lautet: {{$name}}

</body>
</html>